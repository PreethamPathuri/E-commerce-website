<html>
<body>
<?php

include 'Formal shirts.php';

include 'Slogan T-shirts.php';

include 'V-neck T-shirts.php';

include 'Round neck T-shirts.php';


include 'Full sleeve Tees.php';

?>


</body>
</html>