<?php

	
	if(isset($_SESSION['name']))
	{
	 include 'Header2.php'; 
	}
	
	else
	{	
	 include 'Header.php'; 
	}
?>