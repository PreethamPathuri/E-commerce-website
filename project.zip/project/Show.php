<! DOCTYPE HTML>
<head>
<title>FashioMode.com</title>
</head>
<body>

<p align = center><embed src = "NewSlideShow.swf" height = 400 width = 800> </embed></p>

</body>
<html>