<!DOCTYPE html>
<head>

</head>
<body>
<?php

include 'Dresses-Anarkalis.php';

include 'Indo-Ethnic Kurtas & Tops.php';

include 'Saris.php';

include 'Skirts.php';

include 'Trousers and shorts-Pants & Palazzos.php';


include 'Tshirts-Shirts-Tunics-maxi-gown.php';

include 'WeddingClothing.php';

include 'WesternWall.php';


?>


</body>
</html>