<!DOCTYPE html >
<head>
<title>Untitled Document</title>
<link rel = "stylesheet" type = "text/css" href = "mystyle.css">
<link rel = "stylesheet" type = "text/css" href = "menu.css">
</head>
<body >
<table width="100%" bgcolor="#fcebbd" style=" color:black; bottom:0px; font-size:20px;">
  <tr>
    <td class = "f" align="center">Copyright&copy;2020 Hv Boutique  </td>
  </tr>
</table>
</body>
</html>
