<?php
include 'Connection.php';

if(isset($_GET['id']))
{
	
$i = $_GET['id'];

$q = "delete from signuptable where User_id = '$i'";

//$c = mysqli_query($q, $db);
$c = mysqli_query($db,$q) or die("Error: " . mysqli_error($db));


if(!$c)
{
	
	
	echo "<h1> Failed to Delete User........</h1> ";
}
else
{
	header("location:Users.php");
}

}

mysqli_close($db);

?>
