<!DOCTYPE HTML>
<html>
<head>
<link type = "text/css" rel = "stylesheet" href="tables.css">
<link type = "text/css" rel = "stylesheet" href="Headerbtn.css">
<title>Untitled Document</title>
</head>

<body>

<table width="250"  border="1" cellpadding="5" cellspacing="10" bordercolor="#B9B9B9" class="t3">
                <tr>
                    <td align="center" style="background-color:#aaaaaa; color:#FFFFFF;">Men's Corner</td>
                </tr>
				  <tr>
                    <td><a href = "Formal shirts.php" target = "myframe"><button class = "btn5">Formal shirts</button> </a></td>
                  </tr>
                  <tr>
                    <td><a href = "Slogan T-shirts.php" target = "myframe"><button class = "btn5">Slogan T-shirts</button> </a></td>
                  </tr>
				  <tr>
                    <td><a href = "V-neck T-shirts.php" target = "myframe"><button class = "btn5">V-neck T-shirts</button> </a></td>
                  </tr>
				  <tr>
                    <td><a href = "Round neck T-shirts.php" target = "myframe"><button class = "btn5">Round neck T-shirts</button> </a></td>
                  </tr>
				  <tr>
                    <td><a href = "Full sleeve Tees.php" target = "myframe"><button class = "btn5">Full sleeve Tees</button> </a></td>
                  </tr>

	             
              </table></td>

            </tr>
            <tr>
              <td><table width="250" border="1" cellpadding="5" cellspacing="10" bordercolor="#B9B9B9" class="t3">
                  
                <tr>
                    <td align="center" style="background-color:#aaaaaa; color:#FFFFFF;">Woman's Corner</td>
                </tr>
                  <tr>
						<td><a href = "Dresses-Anarkalis.php" target = "myframe"><button class = "btn3">Dresses-Anarkalis</button> </a></td>
                  </tr>
                  <tr>
                    <td><a href = "Indo-Ethnic Kurtas & Tops.php" target = "myframe"><button class = "btn3">Indo-Ethnic Kurtas & Tops</button> </a></td>
                  </tr>
                  <tr>
                    <td><a href = "Saris.php" target = "myframe"><button class = "btn3">Saris</button> </a></td>
                  </tr>
                  <tr>
                    <td><a href = "Skirts.php" target = "myframe"><button class = "btn3">Skirts</button> </a></td>
                  </tr>
                  <tr>
                    <td><a href = "Trousers and shorts-Pants & Palazzos.php" target = "myframe"><button class = "btn4">Trousers and shorts-Pants & Palazzos</button> </a></td>
                  </tr>
                  <tr>
                    <td><a href = "Tshirts-Shirts-Tunics-maxi-gown.php" target = "myframe"><button class = "btn3">Tshirts & Shirts</button> </a></td>
                  </tr>
                  <tr>
                    <td><a href = "WeddingClothing.php" target = "myframe"><button class = "btn3">Wedding clothing</button> </a></td>
                  </tr>
                  
                 
              </table></td>
            </tr>

          </table>

</body>
</html>
